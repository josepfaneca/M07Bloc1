/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.repository;

import cat.xtec.ioc.domain.Xollo;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Josep F.T.
 */
@Repository
public interface XolloRepository {

    void addXollo(Xollo xollo);

    Xollo getXolloByCodi(String codi);

    Set<Xollo> getXolloByFilter(Map<String, List<String>> filterParams);

}
