/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.service;

import cat.xtec.ioc.domain.Xollo;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Josep F.T.
 */

public interface XolloService {

    void addXollo(Xollo xollo);

    Xollo getXolloByCodi(String codi);

    Set<Xollo> getXolloByFilter(Map<String, List<String>> filterParams);

}
