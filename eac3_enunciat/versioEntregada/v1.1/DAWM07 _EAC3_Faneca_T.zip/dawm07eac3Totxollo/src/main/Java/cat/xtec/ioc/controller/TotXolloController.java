package cat.xtec.ioc.controller;

/**
 *
 * @author Josep F.T.
 */
import cat.xtec.ioc.domain.Xollo;
import cat.xtec.ioc.service.XolloService;
import cat.xtec.ioc.utils.Utils;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TotXolloController {

    @Autowired
    private XolloService xolloService;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public ModelAndView homeRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ModelAndView modelview = new ModelAndView("home");
        modelview.getModelMap().addAttribute("banner", "Busca un xollo!");
        modelview.getModelMap().addAttribute("tagline", " ");

        List<Map<String, String>> llista = Utils.getList();
        modelview.getModelMap().addAttribute("options", llista);

        return modelview;
    }

    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public ModelAndView addXolloRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ModelAndView modelview = new ModelAndView("home");
        modelview.getModelMap().addAttribute("banner", "Busca un xollo!");
        modelview.getModelMap().addAttribute("tagline", "Afegir un article al catàleg");

        List<Map<String, String>> llista = Utils.getListAfegir();
        modelview.getModelMap().addAttribute("options", llista);

        return modelview;
    }

    @RequestMapping(value = "/get", method = RequestMethod.GET)
    public ModelAndView getXolloFormRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ModelAndView modelview = new ModelAndView("getXolloForm");
        modelview.getModelMap().addAttribute("banner", "Busca un xollo!");
        return modelview;
    }

    @RequestMapping(value = "/get", method = RequestMethod.POST)
    public ModelAndView getXolloByCodiRequest(@RequestParam("codi") String xolloId, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ModelAndView modelview = new ModelAndView("infoXollo");
        modelview.getModelMap().addAttribute("banner", "Busca un xollo!");
        modelview.getModelMap().addAttribute("tagline", "Dades d'un Xollo.");
        modelview.getModelMap().addAttribute("xollo", xolloService.getXolloByCodi(xolloId));
        return modelview;
    }

    @RequestMapping(value = "/filter", method = RequestMethod.GET)
    public ModelAndView getXolloByFilter(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ModelAndView modelview = new ModelAndView("helpFilter");
        modelview.getModelMap().addAttribute("banner", "Busca un xollo!");
        modelview.getModelMap().addAttribute("tagline", "Ajuda per la creació d'un Filtre.");
        return modelview;
    }

    @RequestMapping(value = "/filter/{ByCriteria}", method = RequestMethod.GET)
    public ModelAndView getXolloByFilter(@MatrixVariable(pathVar = "ByCriteria") Map<String, List<String>> filterParams, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ModelAndView modelview = new ModelAndView("listXolloByFilter");
        modelview.getModelMap().addAttribute("banner", "Busca un xollo!");
        modelview.getModelMap().addAttribute("tagline", "Llistat d'articles que compleixen els requisits.");
        modelview.getModelMap().addAttribute("llista", xolloService.getXolloByFilter(filterParams));
        return modelview;
    }

    @RequestMapping(value = "/venda", method = RequestMethod.GET)
    public ModelAndView getVenda(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ModelAndView modelview = new ModelAndView("helpVendes");
        modelview.getModelMap().addAttribute("banner", "Busca un xollo!");
        modelview.getModelMap().addAttribute("tagline", "Ajuda per la venda d'un article.");

        return modelview;
    }

    /*
    Crea un ModelAndView amb la vista “infoXollo” i li proporciona la següent informació:
banner: «Busca un xollo!»
tagline: «Dades d'un article.»
xollo: Xollo corresponent al codi enviat per l'usuari on es veurà l'augment en
     */
    @RequestMapping(value = "/getXollo/{codi}", method = RequestMethod.GET)
    public ModelAndView getXolloByCodiVendaRequest(@PathVariable("codi") String codi, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ModelAndView modelview = new ModelAndView("infoXollo");
        modelview.getModelMap().addAttribute("banner", "Busca un xollo!");
        modelview.getModelMap().addAttribute("tagline", "Dades d'un article.");
        modelview.getModelMap().addAttribute("xollo", xolloService.getXolloByCodi(codi));

        return modelview;
    }

    @RequestMapping(value = "/add/{tipus}", method = RequestMethod.GET)
    public ModelAndView addXolloForm(@PathVariable("tipus") String tipus, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        ModelAndView modelview = new ModelAndView("add"+tipus);
        modelview.getModelMap().addAttribute("banner", "Busca un xollo!");
        modelview.getModelMap().addAttribute("tagline", "Afegir un article de tipus " + tipus + " al catàleg");
        Object xollo = Class.forName("cat.xtec.ioc.domain." + tipus).newInstance();
        modelview.getModelMap().addAttribute("newXollo", xollo);
        
        return modelview;
    }
    
    @RequestMapping(value = "/add/{tipus}", method = RequestMethod.POST)
    public String addXolloForm (@ModelAttribute("newXollo") Xollo newXolloToAdd ){
        newXolloToAdd.setNumeroReserves(0);
        xolloService.addXollo(newXolloToAdd);
        
        return "redirect:/";
    }

}
