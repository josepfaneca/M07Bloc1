/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.service.impl;

import cat.xtec.ioc.domain.Xollo;
import cat.xtec.ioc.repository.XolloRepository;
import cat.xtec.ioc.service.VendaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Josep F.T.
 */
@Service
public class VendaServiceImpl implements VendaService {

    @Autowired
    private XolloRepository xolloRepository;

    @Override
    public void processVenda(String codiXollo) {

        Xollo xolloById = xolloRepository.getXolloByCodi(codiXollo);

        if (xolloById.getNumeroUnitats() > 0) {
            xolloById.setNumeroReserves(xolloById.getNumeroReserves() + 1);
            xolloById.setNumeroUnitats(xolloById.getNumeroUnitats() - 1);
        } else {
            throw new IllegalArgumentException("No hi ha prou unitats. "
                    + "La quantitat en estoc és: " + xolloById.getNumeroUnitats());
        }

    }

}
