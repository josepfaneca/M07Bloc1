/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.domain;


import java.util.Date;

/**
 *
 * @author Josep F.T.
 */
public class Vol extends Xollo {
    
    private String desti;
    private Date data;
    private Integer persones;

    public Vol() {
    }

    public String getDesti() {
        return desti;
    }

    public void setDesti(String desti) {
        this.desti = desti;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Integer getPersones() {
        return persones;
    }

    public void setPersones(Integer persones) {
        this.persones = persones;
    }
    

}
