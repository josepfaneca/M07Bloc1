/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.domain;



/**
 *
 * @author Josep F.T.
 */
public class Hotel extends Xollo {
    
    private String nom;
    private String habitacio;
    private String direccio;

    public Hotel() {
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getHabitacio() {
        return habitacio;
    }

    public void setHabitacio(String habitacio) {
        this.habitacio = habitacio;
    }

    public String getDireccio() {
        return direccio;
    }

    public void setDireccio(String direccio) {
        this.direccio = direccio;
    }
    
    
    
}
