/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Josep F.T.
 */
public class Utils {

    public static <T> Set<T> convertListToSet(List<T> list) {
        // create an empty set 
        Set<T> set = new HashSet<>();

        // Add each element of list into the set 
        for (T t : list) {
            set.add(t);
        }

        // return the set 
        return set;
    }

    public static List<Map<String, String>> getList() {
        List<Map<String, String>> options = new ArrayList<>();
        //map per la opció afegir
        Map<String, String> map = new HashMap<>();
        map.put("title", "Afegir");
        map.put("desc", "Permet afegir un article al catàleg de la botiga");
        map.put("url", "/add");
        map.put("icon", "glyphicon-plus-sign glyphicon");
        options.add(map);
        map = new HashMap<>();

        //map per l'opció consultar
        map.put("title", "Consultar");
        map.put("desc", "Permet consultar la informació d'un article de la botiga");
        map.put("url", "/get");
        map.put("icon", "glyphicon glyphicon-search");
        options.add(map);
        map = new HashMap<>();

        //map per l'opció filtrar
        map.put("title", "Filtrar");
        map.put("desc", "Permet cercar dins del catàleg de la botiga algun article");
        map.put("url", "/filter");
        map.put("icon", "glyphicon glyphicon-filter");
        options.add(map);
        map = new HashMap<>();

        //map per l'opció comprar
        map.put("title", "Comprar");
        map.put("desc", "Permet comprar algun article de la botiga");
        map.put("url", "/venda");
        map.put("icon", "glyphicon glyphicon-shopping-cart");
        options.add(map);

        return options;
    }

    public static List<Map<String, String>> getListAfegir() {
        List<Map<String, String>> options = new ArrayList<>();
        //map per la opció Vols
        Map<String, String> map = new HashMap<>();
        map.put("title", "Vols");
        map.put("desc", "Permet afegir un vol al catàleg de la botiga");
        map.put("url", "/add/Vol");
        map.put("icon", "glyphicon glyphicon-plane");
        options.add(map);
        map = new HashMap<>();

        //map per l'opció consultar
        map.put("title", "Hotel");
        map.put("desc", "Permet afegir un hotel al catàleg de la botiga");
        map.put("url", "/add/Hotel");
        map.put("icon", "glyphicon glyphicon-bed");
        options.add(map);
        map = new HashMap<>();

        //map per l'opció filtrar
        map.put("title", "Lloguer");
        map.put("desc", "Permet afegir un model de cotxe de lloguer al catàleg de la botiga");
        map.put("url", "/add/Lloguer");
        map.put("icon", "glyphicon glyphicon-oil");
        options.add(map);

        return options;
    }

}
