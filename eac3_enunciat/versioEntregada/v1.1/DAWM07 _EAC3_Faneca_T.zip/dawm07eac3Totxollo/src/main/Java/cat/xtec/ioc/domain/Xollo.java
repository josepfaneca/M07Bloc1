/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.domain;


/**
 *
 * @author Josep F.T.
 */
public class Xollo implements Comparable<Xollo>{
    
    private String codi;
    private String titol;
    private String descripcio;
    private Integer numeroUnitats;
    private Integer numeroReserves;

    public Xollo() {
    }


    @Override
    public int compareTo(Xollo t) {
        return getTitol().compareTo(t.getTitol()); 
    }

    public String getCodi() {
        return codi;
    }

    public void setCodi(String codi) {
        this.codi = codi;
    }

    public String getTitol() {
        return titol;
    }

    public void setTitol(String titol) {
        this.titol = titol;
    }

    public String getDescripcio() {
        return descripcio;
    }

    public void setDescripcio(String descripcio) {
        this.descripcio = descripcio;
    }

    public Integer getNumeroUnitats() {
        return numeroUnitats;
    }

    public void setNumeroUnitats(Integer numeroUnitats) {
        this.numeroUnitats = numeroUnitats;
    }

    public Integer getNumeroReserves() {
        return numeroReserves;
    }

    public void setNumeroReserves(Integer numeroReserves) {
        this.numeroReserves = numeroReserves;
    }
    

}
