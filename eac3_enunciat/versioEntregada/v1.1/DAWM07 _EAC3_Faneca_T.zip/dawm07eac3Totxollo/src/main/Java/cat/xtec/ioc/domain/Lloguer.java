/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.domain;

/**
 *
 * @author Josep F.T.
 */
public class Lloguer extends Xollo {
    
    private String matricula;
    private Boolean hibrid;
    private String marca;

    public Lloguer() {
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public Boolean getHibrid() {
        return hibrid;
    }

    public void setHibrid(Boolean hibrid) {
        this.hibrid = hibrid;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    
    
}
