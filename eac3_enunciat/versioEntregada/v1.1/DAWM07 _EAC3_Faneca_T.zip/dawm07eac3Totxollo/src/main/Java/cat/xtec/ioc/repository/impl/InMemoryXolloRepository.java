/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.repository.impl;

import cat.xtec.ioc.domain.Hotel;
import cat.xtec.ioc.domain.Lloguer;
import cat.xtec.ioc.domain.Vol;
import cat.xtec.ioc.domain.Xollo;
import cat.xtec.ioc.repository.XolloRepository;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Repository;
import java.util.TreeSet;

/**
 *
 * @author Josep F.T.
 */
@Repository
public class InMemoryXolloRepository implements XolloRepository {

    private final List<Xollo> llistaXollos = new ArrayList<>();
    private int num = 1;

    public InMemoryXolloRepository() {

        for (int i = 0; i < 3; i++) {
            Hotel hotel = new Hotel();
            hotel.setCodi("hotelCodi0" + num);
            hotel.setTitol("hotelTitol0" + num);
            hotel.setDescripcio("hotelDescripcio0" + num);
            hotel.setNumeroReserves(1);
            hotel.setNumeroUnitats(3);
            hotel.setDireccio("hotelDireccio0" + num);
            hotel.setHabitacio("hotelHabitacio0" + num);
            hotel.setNom("hotelNom0" + num);
            llistaXollos.add(hotel);
            num++;
        }
        num = 1;
        for (int i = 0; i < 3; i++) {
            Lloguer lloguer = new Lloguer();
            lloguer.setCodi("lloguerCodi0" + num);
            lloguer.setTitol("lloguerTitol0" + num);
            lloguer.setDescripcio("lloguerDescripcio0" + num);
            lloguer.setNumeroReserves(1);
            lloguer.setNumeroUnitats(3);
            lloguer.setHibrid(Boolean.TRUE);
            lloguer.setMarca("lloguerMarca0" + num);
            lloguer.setMatricula("lloguerMatricula0" + num);
            llistaXollos.add(lloguer);
            num++;
        }
        num = 1;
        for (int i = 0; i < 3; i++) {
            Vol vol = new Vol();
            vol.setCodi((i == 0) ? "desti0" : "volCodi0" + num);
            vol.setTitol("volTitol0" + num);
            vol.setDescripcio("volDescripcio0" + num);
            vol.setNumeroReserves(1);
            vol.setNumeroUnitats(3);
            vol.setDesti("volDesti0" + num);
            vol.setPersones(4);
            vol.setData(Calendar.getInstance().getTime());
            llistaXollos.add(vol);
            num++;
        }
    }

    @Override
    public void addXollo(Xollo xollo) {
        llistaXollos.add(xollo);
    }

    @Override
    public Xollo getXolloByCodi(String codi) {
        Xollo xolloByCodi = null;
        for (Xollo xollo : llistaXollos) {
            if (xollo != null && xollo.getCodi() != null
                    && xollo.getCodi().equals(codi)) {
                xolloByCodi = xollo;
                break;
            }
        }
        if (xolloByCodi == null) {
            throw new IllegalArgumentException(
                    "No s'ha trobat xollo amb el codi: " + codi);
        }
        return xolloByCodi;
    }

    @Override
    public Set<Xollo> getXolloByFilter(Map<String, List<String>> filterParams) {
        //2. consultar uns xollos mitjançant el criteri de Tipus i Títol
        List<String> llistaTipus = filterParams.get("tipus");
        List<String> llistaTitols = filterParams.get("title");
        Set<Xollo> returnedXollos = new TreeSet<>();
        for (String tipus : llistaTipus) {
            if (tipus != null && tipus.matches("Vol|Hotel|Lloguer")) {
                switch (tipus) {
                    case "Vol":
                        for (Xollo xollo : llistaXollos) {
                            if (xollo instanceof Vol) {
                                for (String titol : llistaTitols) {
                                    if (xollo.getTitol().toUpperCase().contains(titol.toUpperCase())) {
                                        returnedXollos.add(xollo);
                                    }
                                }
                            }
                        }
                        break;
                    case "Hotel":
                        for (Xollo xollo : llistaXollos) {
                            if (xollo instanceof Hotel) {
                                for (String titol : llistaTitols) {
                                    if (xollo.getTitol().toUpperCase().contains(titol.toUpperCase())) {
                                        returnedXollos.add(xollo);
                                    }
                                }
                            }
                        }
                        break;
                    default:
                        for (Xollo xollo : llistaXollos) {
                            if (xollo instanceof Lloguer) {
                                for (String titol : llistaTitols) {
                                    if (xollo.getTitol().toUpperCase().contains(titol.toUpperCase())) {
                                        returnedXollos.add(xollo);
                                    }
                                }
                            }
                        }
                }
            }
        }
        /*List xollorOrdenats = new ArrayList(returnedXollos);
        Collections.sort(xollorOrdenats, new Comparator<Xollo>() {
            @Override
            public int compare(Xollo x1, Xollo x2) {
                return x1.getTitol().compareTo(x2.getTitol());
            }
        });
        Set set = new TreeSet(xollorOrdenats);*/

        return returnedXollos;
    }

}
