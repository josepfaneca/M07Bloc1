package cat.xtec.ioc.domain.repository.impl;

import cat.xtec.ioc.domain.Vol;
import cat.xtec.ioc.domain.Hotel;
import cat.xtec.ioc.domain.Xollo;
import cat.xtec.ioc.domain.Lloguer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.stereotype.Repository;
import cat.xtec.ioc.domain.repository.XolloRepository;
import java.util.Date;

/**
 *
 * @author Germán Flores
 */
@Repository
public class InMemoryXolloRepository implements XolloRepository {

    private List<Xollo> llista = new ArrayList<Xollo>();

    public InMemoryXolloRepository() {

        Integer codi = 0;

        for (Integer i = 0; i < 3; i++) {
            Vol vol = new Vol("desti" + codi, new Date(), codi, "vol"+codi.toString(), 10, 0, "volTitol" + codi, "volDescripcio" + codi);
            llista.add(vol);
            codi++;
        }
        for (Integer i = 0; i < 3; i++) {
            Hotel hotel = new Hotel("nom" + codi, "habitacio" + codi, "direccio" + codi, "hotel"+codi.toString(), 5, 4, "hotelTitol" + codi, "hotelDescripcio" + codi);
            llista.add(hotel);
            codi++;
        }
        for (Integer i = 0; i < 3; i++) {
            Lloguer lloguer = new Lloguer("matricula" + codi, true, "marca" + codi, "lloguer"+codi.toString(), 10, 9, "lloguerTitol" + codi, "lloguerDescripcio" + codi);
            llista.add(lloguer);
            codi++;
        }
    }

    @Override
    public Xollo getXolloByCodi(String codi) {
        Xollo xolloByCodi = null;
        for (Xollo r : llista) {
            if (r != null && r.getCodi() != null
                    && r.getCodi().equals(codi)) {
                xolloByCodi = r;
                break;
            }
        }
        if (xolloByCodi == null) {
            throw new IllegalArgumentException(
                    "No s'ha trobat el xollo amb el codi: " + codi);
        }
        return xolloByCodi;
    }

    @Override
    public void addXollo(Xollo recurs) {
        this.llista.add(recurs);
    }

    @Override
    public Set<Xollo> getXolloByFilter(Map<String, List<String>> filterParams) {
        Set<Xollo> xolloByTipus = new HashSet<Xollo>();
        Set<Xollo> xolloByTitle = new HashSet<Xollo>();
        Set<String> criterias = filterParams.keySet();

        if (criterias.contains("tipus")) {
            for(String tipusParam : filterParams.get("tipus")) {
                for (Xollo r : llista) {
                    try {
                        if (Class.forName("cat.xtec.ioc.domain." + tipusParam).isInstance(r)) {
                            xolloByTipus.add(r);
                        }
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(InMemoryXolloRepository.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
        if (criterias.contains("title")) {
            for(String titleParam : filterParams.get("title")) {
                for (Xollo r : llista) {
                    if (r.getTitol().toLowerCase().contains(titleParam.toLowerCase())) {
                        xolloByTitle.add(r);
                    }
                }
            }
        }
        xolloByTipus.retainAll(xolloByTitle);
        return xolloByTipus;
    }

}
