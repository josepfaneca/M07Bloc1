package cat.xtec.ioc.domain;

import java.util.Date;

/**
 *
 * @author Germán Flores
 */
public class Vol extends Xollo {

    protected String desti;
    protected Date data;
    protected Integer persones;

    public Vol(String desti, Date data, Integer persones, String codi, Integer numeroUnitats, Integer numeroReserves, String titol, String descripcio) {
        super(codi, numeroUnitats, numeroReserves, titol, descripcio);
        this.desti = desti;
        this.data = data;
        this.persones = persones;
    }

    public Vol() {
        super();
    }

    public String getDesti() {
        return desti;
    }

    public void setDesti(String desti) {
        this.desti = desti;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Integer getPersones() {
        return persones;
    }

    public void setPersones(Integer persones) {
        this.persones = persones;
    }


}
