package cat.xtec.ioc.domain.repository;

import cat.xtec.ioc.domain.Xollo;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Germán Flores
 */
public interface XolloRepository {
    
    void addXollo(Xollo xollo);
            
    Xollo getXolloByCodi(String codi);
    
    Set<Xollo> getXolloByFilter(Map<String, List<String>> filterParams);
    
}
