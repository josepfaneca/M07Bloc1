package cat.xtec.ioc.service;

/**
 *
 * @author Germán Flores
 */
public interface VendaService {
    void processVenda(String codiXollo); 
}
