
package cat.xtec.ioc.domain;

/**
 *
 * @author Germán Flores
 */
public class Lloguer extends Xollo{
    private String matricula;
    private Boolean hibrid;
    private String marca;

    public Lloguer() {
        super();
    }

    public Lloguer(String matricula, Boolean hibrid, String marca, String codi, Integer numeroUnitats, Integer numeroReserves, String titol, String descripcio) {
        super(codi, numeroUnitats, numeroReserves, titol, descripcio);
        this.matricula = matricula;
        this.hibrid = hibrid;
        this.marca = marca;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public Boolean getHibrid() {
        return hibrid;
    }

    public void setHibrid(Boolean hibrid) {
        this.hibrid = hibrid;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }


    
    
}
