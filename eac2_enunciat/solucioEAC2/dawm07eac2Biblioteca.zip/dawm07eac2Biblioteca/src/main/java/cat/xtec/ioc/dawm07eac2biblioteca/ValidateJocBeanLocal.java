package cat.xtec.ioc.dawm07eac2biblioteca;

import javax.ejb.Local;

/**
 *
 * @author German
 */
@Local
public interface ValidateJocBeanLocal {
    public Boolean isValidFileImageName(String jocName, String fileImageName);
}
